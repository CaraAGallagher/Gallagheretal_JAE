# README for: Energy-mediated responses to changing prey size and distribution in marine top predator movements and population dynamics  

Cara A. Gallagher^1,2^, Marianna Chimienti^1,3^, Volker Grimm^2,4^, and Jacob Nabe-Nielsen^1^  

^1^ Aarhus University, Department of Bioscience, Frederiksborgvej 399, PO Box 358, DK-4000 Roskilde, Denmark  
^2^ University of Potsdam, Plant Ecology and Nature Conservation, Am Mühlenberg 3, 14476 Potsdam, Germany  
^3^ Centre d'Etudes Biologiques de Chizé, 405 Route de Prissé la Charrière, 79360 Villiers-en-Bois, France   
^4^ Helmholtz Centre for Environmental Research – UFZ, Department of Ecological Modelling, Permoserstraße 15, 04318 Leipzig, Germany  

# Porpoise Energy Budget Model Code

Simulating the energetics and population dynamics of harbor porpoises in theoretical seascapes.

The model was developed as part of the DEPONS project (Disturbance Effects of POrpoises in the North Sea) at Aarhus University, Denmark. The code was developed in NetLogo and must be used in this software. Please install the code from the zip-file to ensure that all the necessary input files are available and located in the right directories. This model builds on a previous model of porpoise movements which can be found at https://github.com/jacobnabe/PorpoiseModel.  

If you have any questions please contact Cara Gallagher at cgallagher@bios.au.dk or gallagher@uni-potsdam.de

File extensions:   
.nlogo  
.R  
.csv    
.asc  
.txt  

Brief folder description::  

The environmentals folder contains two subfolders: raster-data and thermophysical-properties-of-SW-tables. The raster-data folder contains the files used for importing spatially-explicit environmental data stored as .asc or .txt files into the model environment. Bathy.asc contains bathymetric data, blocks.asc sets up the block locations used in output analysis, disttocoast.asc assigns a numeric distance to the coastline for each patch, mean_maxent_values.txt contains the mean maxent values for each season used for the entire map, patches.asc assigns the food patch locations, and quarter1-4.asc assign the maxent values to those food patches. The thermophysical-properties-of-SW-tables folder contains matrices loaded into the model on start up to convert the current temperature and salinity values to the various thermophysical properties of seawater used in model calculations (CoefOfThermalExpansionTable.csv = coefficient of thermal expansion, DensityTable.csv = density, DynamicVis.csv = dynamic viscosity, SpecificHeat.csv = specific heat capacity, ThermalConductivity.csv = thermal conductivity; see the supplementary TRACE document for units and details).  

The output folder stores output files.  

The porpoise-initialization-files folder contains the age-class specific values from real porpoises used for assigning modelled porpoise morphometrics at setup. Age-class is specified at the end of each file name. Rows represent data for individual porpoises in the unpublished harbor porpoise dataset from C. Kinze and A. Galatius. Columns are defined as follows: Age = age in years, StndL = standard length in meters, Weight = mass in kilograms, Blubber.mass = mass of blubber in kilograms, BlubPercent = the percentage of body mass composed of blubber, columns F - T represent the recorded blubber depth in centimeters at each of nine body sites where the number (1-5) represents the girth line position (see TRACE Section 3) and the first letter denotes the position along the girth line (D = dorsal, L = lateral, and V = ventral).   
  
PEB_Model_IDW.nlogo is the ABM model, programmed in NetLogo.  


Full directory::  

```bash
Gallagheretal_Code/  
??? environmentals/  
?   ??? raster-data/  
?   ?   ??? Homogeneous/  
?   ?       ??? bathy.asc  
?   ?       ??? blocks.asc  
?   ?       ??? disttocoast.asc  
?   ?       ??? mean_maxent_values.txt  
?   ?       ??? patches.asc  
?   ?       ??? patches2.asc  
?   ?       ??? patches12.asc  
?   ?       ??? patches22.asc  
?   ?       ??? quarter1.asc  
?   ?       ??? quarter2.asc  
?   ?       ??? quarter3.asc  
?   ?       ??? quarter4.asc  
?   ??? thermophysical-properties-of-SW-tables/  
?       ??? CoefOfThermalExpansionTable.csv  
?       ??? DensityTable.csv  
?       ??? DynamicVis.csv  
?       ??? SpecificHeat.csv  
?       ??? ThermalConductivity.csv  
??? output/  
??? porpoise-initialization-files/  
?   ??? PorpoiseInitializationBlubber.csv  
?   ??? PorpoiseInitializationBlubber_Zero.csv  
?   ??? PorpoiseInitializationBlubber_One.csv  
?   ??? PorpoiseInitializationBlubber_Two.csv  
?   ??? PorpoiseInitializationBlubber_Three.csv  
?   ??? PorpoiseInitializationBlubber_Four.csv  
?   ??? PorpoiseInitializationBlubber_Five.csv  
?   ??? PorpoiseInitializationBlubber_Six.csv  
?   ??? PorpoiseInitializationBlubber_Seven_up.csv  
??? .gitignore  
??? PEB_Model_IDW.nlogo  
??? README.md  
```