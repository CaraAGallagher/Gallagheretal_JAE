# README for: Energy-mediated responses to changing prey size and distribution in marine top predator movements and population dynamics  

Cara A. Gallagher^1,2^, Marianna Chimienti^1,3^, Volker Grimm^2,4^, and Jacob Nabe-Nielsen^1^  

^1^ Aarhus University, Department of Bioscience, Frederiksborgvej 399, PO Box 358, DK-4000 Roskilde, Denmark  
^2^ University of Potsdam, Plant Ecology and Nature Conservation, Am Mühlenberg 3, 14476 Potsdam, Germany  
^3^ Centre d'Etudes Biologiques de Chizé, 405 Route de Prissé la Charrière, 79360 Villiers-en-Bois, France   
^4^ Helmholtz Centre for Environmental Research – UFZ, Department of Ecological Modelling, Permoserstraße 15, 04318 Leipzig, Germany  


# Figure recreation files

This folder contains the files needed to reproduce paper figures 1-6. Additionally the code to run the HMM is found in this folder. We encourage users to use the Rproject to access files.  

For questions, please contact Cara A. Gallagher at gallagher@uni-potsdam.de or carag16@gmail.com.

File extensions:   
.Rproj  
.R   
.csv     
.asc  
.RData  

Files needed for each figure::  
Figure 1:  
-Script: Fig1_SeascapeMapGenerator.R  
-Input files: ModelOutputs/ExampleTracks/trackAgg2.txt  
              ModelOutputs/ExampleTracks/trackAgg12.txt  
              ModelOutputs/ExampleTracks/trackAgg22.txt  

Figure 2:  
-Script: Fig2_ScenarioExample.R  
-Input files: ModelOutputs/ScenarioEnvFishExample.csv  

Figure 3:  
-Script: Fig3_UniqueFoodCellEncounterRate.R  
-Input files: ModelOutputs/SpaceUseOut.csv  

Figure 4 and HMM code:  
-Script: Fig4_HiddenMarkovModel.R  
-Input files: ModelOutputs/MoveDataHMM.csv  
              ModelOutputs/MoveModsTransProbsAllCombos.xlsx  

Figure 5:  
-Script: Fig5_BodyMassPerAgeClass.R  
-Input files: ModelOutputs/MassAgeClassOut.csv   

Figure 6:  
-Script: Fig6_PopulationSize:R  
-Input files: ModelOutputs/PopSizeOut.csv  
              
Figure 7:  
-Script: Fig7_IncreasedConsumption.R  
-Input files: ModelOutputs/IncreasedIngestionNFishOut.csv  
              