# Cara Gallagher
# updated 25 August 2021
# Porpoise Energy Budget outputs
# Figure 6 in Gallagher et al. (2021)
# See main text and TRACE section 7 for details

library(wesanderson)
library(tidyverse)

################ colors #######################

pal <- rev(wes_palette("Zissou1", 5, type = "continuous"))

############### Population size outputs #####################

popOut <- read_csv("data/ModelOutputs/PopSizeOut.csv")

# prep data for plotting
popOut <- popOut %>% 
  group_by(aggLev,lgthFish, year,climateChange) %>% 
  summarise(meanPop = mean(population, na.rm = T), sdPop = sd(population, na.rm = T)) %>% 
  filter(climateChange == "mean")

aggLev.labs <- c("Low", "Moderate", "High")
names(aggLev.labs) <- c(2,12,22)

Figure6 <- ggplot(popOut, aes(x = year, y = meanPop)) + 
  geom_hline(yintercept=200, color = "gray40", alpha = 0.25, size=0.75) +
  geom_line(aes(col = as.factor(lgthFish)), size = 1.1) + 
  facet_grid(. ~ aggLev, labeller = labeller(aggLev = aggLev.labs)) + 
  scale_color_manual(values = pal) +
  scale_x_continuous(breaks = c(10.0,12.0,14,16.0,18,20.0), labels = c(10,12,14,16,18,20)) +
  labs(col = "Final fish length [cm]", x = "Year", y = "Count agents") +
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())+ theme(legend.position="bottom")
Figure6



