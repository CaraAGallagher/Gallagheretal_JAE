# Cara Gallagher
# updated 25 August 2021
# Porpoise Energy Budget outputs
# Figure 5 in Gallagher et al. (2021)
# See main text and TRACE section 7 for details

library(wesanderson)
library(tidyverse)
library(see)
library(patchwork)

################ colors #######################

pal1 <- wes_palette("Royal2", 3, type = "continuous")
pal2 <- wes_palette("Zissou1", 5, type = "discrete")
pal3 <- wes_palette("GrandBudapest2", 3, type = "discrete")

############### Body mass per age class outputs #####################

MassACOut <- read_csv("data/ModelOutputs/MassAgeClassOut.csv")

# prep data for plotting
MassACOut <-  MassACOut %>% 
  mutate(year = week / 52) %>% 
  ungroup() %>% 
  select(-week, -runNum) %>% 
  gather(key = "metric", value = "val", -aggLev,-lgthFish, -climateChange, -year) %>%  
  filter(val != 0)

# used to plot using differing y limits but without altering whisker length
calc_boxplot_stat <- function(x) {
  coef <- 1.5
  n <- sum(!is.na(x))
  # calculate quantiles
  stats <- quantile(x, probs = c(0.0, 0.25, 0.5, 0.75, 1.0))
  names(stats) <- c("ymin", "lower", "middle", "upper", "ymax")
  iqr <- diff(stats[c(2, 4)])
  # set whiskers
  outliers <- x < (stats[2] - coef * iqr) | x > (stats[4] + coef * iqr)
  if (any(outliers)) {
    stats[c(1, 5)] <- range(c(stats[2:4], x[!outliers]), na.rm = TRUE)
  }
  return(stats)
}

## outputs per climate change level
MassCC <- ggplot(MassACOut, aes(x = climateChange, y = val, fill = climateChange, col = climateChange)) + 
  stat_summary(fun.data = calc_boxplot_stat, geom="boxplot", size = 1.1, width = 0.25, alpha = 0.25, show.legend = FALSE) + 
  facet_wrap(. ~ metric, scales = "free", labeller = labeller(metric = c("calves" = "Calves","juvs" = "Juveniles","nonLact" = "Non-lactating adults","lact" = "Lactating adults"))) +
  scale_color_manual(values = pal3) +
  scale_fill_manual(values = pal3) +
  labs(x = "Climate change level", y = "Body mass [kg]") +
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())+ theme(legend.position="bottom")


## outputs per spatial aggregation level
MassAL <- ggplot(MassACOut, aes(x = as.factor(aggLev), y = val, fill = as.factor(aggLev), col = as.factor(aggLev))) + 
  stat_summary(fun.data = calc_boxplot_stat, geom="boxplot", size = 1.1, width = 0.25, alpha = 0.25, show.legend = FALSE) + 
  facet_wrap(. ~ metric, scales = "free", labeller = labeller(metric = c("calves" = "Calves","juvs" = "Juveniles","nonLact" = "Non-lactating adults","lact" = "Lactating adults"))) +
  scale_color_manual(values = pal1) +
  scale_fill_manual(values = pal1) +
  scale_x_discrete(breaks = c(2,12,22), labels = c("Low", "Moderate", "High")) +
  labs(x = "Spatial aggregation level", y = "Body mass [kg]") +
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())+ theme(legend.position="bottom")


## outputs per fish length
MassFL <- ggplot(MassACOut, aes(x = as.factor(lgthFish), y = val, fill = as.factor(lgthFish), col = as.factor(lgthFish))) + 
  stat_summary(fun.data = calc_boxplot_stat, geom="boxplot", size = 1.1, width = 0.25, alpha = 0.25, show.legend = FALSE) + 
  facet_wrap(. ~ metric, scales = "free", labeller = labeller(metric = c("calves" = "Calves","juvs" = "Juveniles","nonLact" = "Non-lactating adults","lact" = "Lactating adults"))) +
  scale_color_manual(values = pal2) +
  scale_fill_manual(values = pal2) +
  labs(x = "Final fish length [cm]", y = "Body mass [kg]") +
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())+ theme(legend.position="bottom")

## all together

Figure5 <- (MassAL + MassFL) / (MassCC + plot_spacer()) + 
  plot_layout(widths = c(1,1)) +  
  plot_annotation(tag_levels = 'A') & 
  theme(plot.tag = element_text(colour = 'grey40', family = 'sans'))
Figure5




