# Cara Gallagher
# updated 25 August 2021
# Scenario example plot of temperature, salinity, fish length, and fish weight changes in time
# Figure 2 in Gallagher et al. (2021)
# See main text and TRACE section 7 for details

library(tidyverse)

TSF <- read_csv("data/ModelOutputs/ScenarioEnvFishExample.csv")

########### pulling info to make trend lines for temp and salinity ############

metricLabs <- c(fLength = "Length [cm]", fWeight = "Weight [g]", sal = "Salinity [PSU]", temp ="Temperature [°C]")

Figure2 <- ggplot(TSF, aes(x = day, y = value, col = scen)) + 
  geom_line(size = 1) + 
  facet_wrap(.~metric, nrow = 4, scales = "free_y", labeller = labeller(metric = metricLabs), strip.position = "left")  +
  scale_x_continuous(breaks = c(0, 1800, 3600, 5400, 7200), labels = c(0,5,10,15,20)) +
  labs(x = "Year") +
  theme(
   # legend.position = "none",
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.title.y = element_blank(),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.y = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank(),
    strip.background = element_blank(),
    strip.placement = "outside")
Figure2


