# Cara Gallagher
# updated 25 August 2021
# Porpoise Energy Budget outputs
# Figure 7 in Gallagher et al. (2021)
# See main text and TRACE section 7 for details

library(RColorBrewer)
library(tidyverse)
library(patchwork)

################ colors #######################

pal <- brewer.pal(n = 7, name = "GnBu")
pal <- pal[3:7]

############### Increased consumption outputs #####################

IIPopOut <- read_csv("data/ModelOutputs/IncreasedIngestionOut.csv")

# prep data for plotting

IIPopOut <- IIPopOut %>% 
  group_by(aggLev,ing,abun,year) %>% 
  summarise(meanPop = mean(population, na.rm = T), sdPop = sd(population, na.rm = T)) 


IIPopOut12 <- IIPopOut %>% filter(aggLev == 12)
Figure7 <- ggplot(IIPopOut12, aes(x = year, y = meanPop, col = as.factor(ing))) + 
  geom_hline(yintercept=200, color = "gray40", alpha = 0.25, size=0.75) +
  geom_line(size = 1.1) + 
  facet_wrap(.~abun) + 
  scale_color_manual(values = pal) +
  scale_x_continuous(breaks = c(10.0,12.0,14,16.0,18,20.0), labels = c(10,12,14,16,18,20)) +
  labs(col = "Ingestion rate increase [%]", x = "Year", y = "Count agents") +
  #  theme_classic()+
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())
Figure7


IIPopOut2 <- IIPopOut %>% filter(aggLev == 2)
IIPopOut2 <- ggplot(IIPopOut2, aes(x = year, y = meanPop, col = as.factor(ing))) + 
  geom_hline(yintercept=120, color = "gray40", alpha = 0.25, size=0.75) +
  geom_line(size = 1.1) + 
  facet_wrap(.~abun) + 
  scale_color_manual(values = pal) +
  scale_x_continuous(breaks = c(10.0,12.0,14,16.0,18,20.0), labels = c(10,12,14,16,18,20)) +
  labs(col = "Ingestion rate increase [%]", x = "Year", y = "Count agents") +
  #  theme_classic()+
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())
IIPopOut2

IIPopOut22 <- IIPopOut %>% filter(aggLev == 22)
IIPopOut22 <- ggplot(IIPopOut22, aes(x = year, y = meanPop, col = as.factor(ing))) + 
  geom_hline(yintercept=240, color = "gray40", alpha = 0.25, size=0.75) +
  geom_line(size = 1.1) + 
  facet_wrap(.~abun) + 
  scale_color_manual(values = pal) +
  scale_x_continuous(breaks = c(10.0,12.0,14,16.0,18,20.0), labels = c(10,12,14,16,18,20)) +
  labs(col = "Ingestion rate increase [%]", x = "Year", y = "Count agents") +
  #  theme_classic()+
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 9, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    panel.background = element_blank())
IIPopOut22


########################## Change in fish eaten ##########################

IIFishOut <- read_csv("data/ModelOutputs/IncreasedIngestionNFishOut.csv")

# prep data for plotting
aggLev.labs <- c("Low", "Moderate", "High")
names(aggLev.labs) <- c(2,12,22)

IIFishOutSum <- IIFishOut %>% 
  mutate(year = floor(year)) %>% 
  group_by(year, aggLev) %>% 
  summarise(meanFood = mean(food, na.rm = T), sdFood = sd(food, na.rm = T)) 


IIFishYr <- ggplot(IIFishOutSum, aes(x = year)) + 
  geom_ribbon(aes(ymax = meanFood + sdFood, ymin = meanFood - sdFood), alpha = 0.25) + 
  geom_line(aes(y = meanFood), size = 1.1) + 
  scale_color_manual(values = pal) +
  scale_x_continuous(breaks = c(0,2,4,6,8,10), labels = c(10,12,14,16,18,20)) +
  labs(x = "Year", y = "Daily ingestion rate [N fish]") +
  facet_grid(. ~ aggLev, labeller = labeller(aggLev = aggLev.labs)) +
  theme(
    axis.title = element_text(size = 12, color = "gray40", face = "bold"),
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 12, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 10, color = "gray40", face = "bold"),
    legend.title = element_text(size = 12, color = "gray40", face = "bold"),
    panel.background = element_blank())+ theme(legend.position="bottom")
IIFishYr


IIFishOutChange <- IIFishOut %>% 
  mutate(year = floor(year)) %>% 
  group_by(runNum, year, aggLev) %>% 
  summarise(meanFood = mean(food, na.rm = T)) %>% 
  filter(year == 0 | year == 9) %>% 
  mutate(time = ifelse(year == 0, "min", "max")) %>% 
  pivot_wider(names_from = time, values_from = c(year,meanFood,time)) %>% 
  select(-year_min, -year_max, -time_min, -time_max) %>% 
  mutate(change = (meanFood_max - meanFood_min) / meanFood_min * 100)


IIFishChange <- ggplot(IIFishOutChange, aes(x = as.factor(aggLev), y = change)) + 
  geom_violin(size = 1.1) + 
  geom_boxplot(width = 0.5,size = 1.1) + 
  geom_jitter(width = 0.1,size = 2) +
  labs(x = "Spatial aggregation level", y = "Change in count fish consumed daily [%]") +
  scale_x_discrete(breaks = c(2,12,22), labels = c("Low", "Moderate", "High")) +
  theme(
    axis.title = element_text(size = 12, color = "gray40", face = "bold"),
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    strip.text.x = element_text(size = 12, color = "gray40", face = "bold"), 
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    legend.text = element_text(size = 10, color = "gray40", face = "bold"),
    legend.title = element_text(size = 12, color = "gray40", face = "bold"),
    panel.background = element_blank())+ theme(legend.position="bottom")
IIFishChange


AppendIIFigure <- IIFishYr / IIFishChange + 
  plot_layout(heights = c(0.9, 1.1))
AppendIIFigure

