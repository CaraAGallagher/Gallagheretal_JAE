# Cara Gallagher
# updated 25 August 2021
# Theoretical seascape generator
# Figure 1 in Gallagher et al. (2021)
# See main text for details

library(NLMR)
library(landscapetools)
library(raster)
library(tidyverse)
library(patchwork)
library(RColorBrewer)
library(svglite)

# base values for gaussian field function: m <- nlm_gaussianfield(60, 100, resolution = 400, autocorr_range = 10, mag_var = 5, nug = 0.2, mean = 1, user_seed = NULL,rescale = TRUE)

nFish <- 10000

################### create seascapes ################### 

# seascape with aggregation level = 2
m <- nlm_gaussianfield(600, 1000, resolution = 400, autocorr_range = 2, mag_var = 5, nug = 0.2, mean = 1, user_seed = 100, rescale = TRUE)
f2 <- landscapetools::util_classify(m, weighting = c(0.984, 0.016))
fextract <- as.data.frame(rasterToPoints(f2))
fextract <- fextract[which(fextract$layer == 1),1:2]
mextract <- raster::extract(m, fextract, cellnumbers = TRUE)[,"cells"]
m[mextract] <- NA
map2 <- calc(m, fun = function(x){(x/cellStats(m, sum))*nFish})
map2[is.na(map2[])] <- 0 

# seascape with aggregation level = 12
m <- nlm_gaussianfield(600, 1000, resolution = 400, autocorr_range = 12, mag_var = 5, nug = 0.2, mean = 1, user_seed = 100, rescale = TRUE)
f12 <- landscapetools::util_classify(m, weighting = c(0.984, 0.016))
fextract <- as.data.frame(rasterToPoints(f12))
fextract <- fextract[which(fextract$layer == 1),1:2]
mextract <- raster::extract(m, fextract, cellnumbers = TRUE)[,"cells"]
m[mextract] <- NA
map12 <- calc(m, fun = function(x){(x/cellStats(m, sum))*nFish})
map12[is.na(map12[])] <- 0 

# seascape with aggregation level = 22
m <- nlm_gaussianfield(600, 1000, resolution = 400, autocorr_range = 22, mag_var = 5, nug = 0.2, mean = 1, user_seed = 100, rescale = TRUE)
f22 <- landscapetools::util_classify(m, weighting = c(0.984, 0.016))
fextract <- as.data.frame(rasterToPoints(f22))
fextract <- fextract[which(fextract$layer == 1),1:2]
mextract <- raster::extract(m, fextract, cellnumbers = TRUE)[,"cells"]
m[mextract] <- NA
map22 <- calc(m, fun = function(x){(x/cellStats(m, sum))*nFish})
map22[is.na(map22[])] <- 0 

################### plots ################### 
pal <- brewer.pal(n = 9, name = 'Greens')
pal <- pal[3:9]

totA2 <- map2 * 240
totA12 <- map12 * 240
totA22 <- map22 * 240


Track2 <- read_delim("data/ModelOutputs/ExampleTracks/trackAgg2.txt", delim = " ", col_names = TRUE)

Track2 <- Track2 %>% 
  rename(pos_x = `utm-x`, pos_y = `utm-y`) %>% 
  select(-block)

Track12 <- read_delim("data/ModelOutputs/ExampleTracks/trackAgg12.txt", delim = " ", col_names = TRUE)

Track12 <- Track12 %>% 
  rename(pos_x = `utm-x`, pos_y = `utm-y`) %>% 
  select(-block) 

Track22 <- read_delim("data/ModelOutputs/ExampleTracks/trackAgg22.txt", delim = " ", col_names = TRUE)

Track22 <- Track22 %>% 
  rename(pos_x = `utm-x`, pos_y = `utm-y`) %>% 
  select(-block) 


plot2 <- show_landscape(totA2) + 
  scale_fill_gradientn(colors = pal, limits = c(225,300), na.value = "grey95") +
  geom_path(data = Track2, aes(x = pos_x, y = pos_y), size = 0.5, col ="black", alpha = 0.2)+
  theme_classic() + 
  annotate("rect",xmin = 200*400, xmax = 400*400, ymin = 500*400, ymax = 600*400, fill=NA, col = "gray40", size = 1.25) +
  annotate("text", x = 50*400, y = 950*400, label = "a)", size = 5, color = "gray40", family = "sans",  fontface = "bold") +
  scale_x_continuous(breaks = c(0, 40000, 80000, 120000, 160000, 200000, 240000), labels = c(0, 100, 200, 300, 400, 500, 600),expand = c(0,0)) +
  scale_y_continuous(breaks = c(0, 80000, 160000, 240000, 800*400, 1000*400), labels = c(0, 200, 400, 600, 800, 1000),expand = c(0,0)) +
  labs(x = "Easting [cells]", y = "Northing [cells]", fill = "nFish") +
  theme(
      legend.position = "none",
      plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
      axis.title = element_text(size = 11, color = "gray40", face = "bold"),
      axis.text = element_text(size = 10, color = "gray40", face = "bold"),
      axis.line = element_line(colour = "gray40", size=0.9),
      axis.ticks= element_line(colour = "gray40", size=0.9),
      panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
      panel.background = element_blank())

plot12 <- show_landscape(totA12) + 
  scale_fill_gradientn(colors = pal, limits = c(225,300), na.value = "grey95") +
  geom_path(data = Track12, aes(x = pos_x, y = pos_y), size = 0.5, col ="black", alpha = 0.2)+
  theme_classic() + 
  annotate("rect",xmin = 200*400, xmax = 400*400, ymin = 500*400, ymax = 600*400, fill=NA, col = "gray40", size = 1.25) +
  annotate("text", x = 50*400, y = 950*400, label = "b)", size = 5, color = "gray40", family = "sans",  fontface = "bold") +
  scale_x_continuous(breaks = c(0, 40000, 80000, 120000, 160000, 200000, 240000), labels = c(0, 100, 200, 300, 400, 500, 600),expand = c(0,0)) +
  scale_y_continuous(breaks = c(0, 80000, 160000, 240000, 800*400, 1000*400), labels = c(0, 200, 400, 600, 800, 1000),expand = c(0,0)) +
  labs(x = "Easting [cells]", y = "Northing [cells]", fill = "nFish") +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 11, color = "gray40", face = "bold"),
    axis.title.y=element_blank(),
    axis.text.y=element_blank(),
    plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank())

plot22 <- show_landscape(totA22) + 
  scale_fill_gradientn(colors = pal, limits = c(225,300), breaks = c(240,265,290), na.value = "grey95",
                       guide=guide_colorbar(
                       barheight = unit(2, units = "mm"),
                       barwidth = unit(50, units = "mm"),
                       draw.ulim = F,
                       frame.colour = "gray40",
                       direction = "horizontal",
                       frame.linewidth = 0.75,
                       ticks = FALSE,
                       title.position = "top",
                       label.position = "bottom")) +
  geom_path(data = Track22, aes(x = pos_x, y = pos_y), size = 0.5, col ="black", alpha = 0.2)+
  theme_classic() + 
  annotate("rect",xmin = 200*400, xmax = 400*400, ymin = 500*400, ymax = 600*400, fill=NA, col = "gray40", size = 1.25) +
  annotate("text", x = 50*400, y = 950*400, label = "c)", size = 5, color = "gray40", family = "sans",  fontface = "bold") +
  scale_x_continuous(breaks = c(0, 40000, 80000, 120000, 160000, 200000, 240000), labels = c(0, 100, 200, 300, 400, 500, 600),expand = c(0,0)) +
  scale_y_continuous(breaks = c(0, 80000, 160000, 240000, 800*400, 1000*400), labels = c(0, 200, 400, 600, 800, 1000),expand = c(0,0)) +
  labs(x = "Easting [cells]", y = "Northing [cells]", fill = "Fish per cell") +
  theme(
    axis.title = element_text(size = 11, color = "gray40", face = "bold"),
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    axis.title.y=element_blank(),
    axis.text.y=element_blank(),
    plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
    legend.text = element_text(size = 10, color = "gray40", face = "bold"),
    legend.title = element_text(size = 11, color = "gray40", face = "bold", hjust = 0.5),
    legend.box.margin = margin(0, 0, 0, 1, "cm"),
    legend.background =element_blank(),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank()) 

######## small figs ############

# crop to zoomed in region
b <- extent(200*400, 400*400, 500*400, 600*400)
totA2B <- crop(totA2, b)
totA12B <- crop(totA12, b)
totA22B <- crop(totA22, b)


plot2sm <- show_landscape(totA2B) + 
  scale_fill_gradientn(colors = pal, limits = c(225,300), na.value = "grey95") +
  theme_classic() + 
  annotate("rect",xmin = 200*400, xmax = 400*400, ymin = 500*400, ymax = 600*400, fill=NA, col = "gray40", size = 2.0) +
  scale_x_continuous(breaks = c(201*400, 300*400, 398*400), labels = c(200, 300, 400),expand = c(0,0)) +
  scale_y_continuous(breaks = c(501*400, 550*400, 599*400), labels = c(500, 550, 600),expand = c(0,0)) +
  labs(x = NULL, y = "Northing [cells]") +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 11, color = "gray40", face = "bold"),
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    plot.margin = margin(0, 0.2, 0, 0.2, "cm"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_blank(),
    panel.background = element_blank())

plot12sm <- show_landscape(totA12B) + 
  scale_fill_gradientn(colors = pal, limits = c(225,300), na.value = "grey95") +
  theme_classic() + 
  annotate("rect",xmin = 200*400, xmax = 400*400, ymin = 500*400, ymax = 600*400, fill=NA, col = "gray40", size = 2.0) +
  scale_x_continuous(breaks = c(202*400, 300*400, 398*400), labels = c(200, 300, 400),expand = c(0,0)) +
  scale_y_continuous(breaks = c(501*400, 550*400, 599*400), labels = c(500, 550, 600),expand = c(0,0)) +
  labs(x = NULL, y = "Northing [cells]") +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 11, color = "gray40", face = "bold"),
    axis.title.y = element_blank(),
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    axis.text.y = element_blank(),
    plot.margin = margin(0, 0.2, 0, 0.2, "cm"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_blank(),
    panel.background = element_blank())

plot22sm <- show_landscape(totA22B) + 
  scale_fill_gradientn(colors = pal, limits = c(225,300), na.value = "grey95") +
  theme_classic() + 
  annotate("rect",xmin = 200*400, xmax = 400*400, ymin = 500*400, ymax = 600*400, fill=NA, col = "gray40", size = 2.0) +
  scale_x_continuous(breaks = c(202*400, 300*400, 399*400), labels = c(200, 300, 400),expand = c(0,0)) +
  scale_y_continuous(breaks = c(501*400, 550*400, 599*400), labels = c(500, 550, 600),expand = c(0,0)) +
  labs(x = NULL, y = "Northing [cells]") +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 11, color = "gray40", face = "bold"),
    axis.title.y = element_blank(),
    axis.text = element_text(size = 10, color = "gray40", face = "bold"),
    axis.text.y = element_blank(),
    plot.margin = margin(0, 0.2, 0, 0.2, "cm"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_blank(),
    panel.background = element_blank())


## Function to extract legend
g_legend <- function(a.gplot){ 
  tmp <- ggplot_gtable(ggplot_build(a.gplot)) 
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box") 
  legend <- tmp$grobs[[leg]] 
  legend
} 


legend <- g_legend(plot22) 

# combined plot
Figure1 <- ((( plot2 + plot12 + (plot22 + theme(legend.position = "none") )) / ( plot2sm + plot12sm + plot22sm )) / legend) +plot_layout(heights = c(2, 0.75, 0.15))
Figure1
