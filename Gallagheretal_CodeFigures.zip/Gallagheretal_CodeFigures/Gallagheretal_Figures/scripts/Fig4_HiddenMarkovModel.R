# Cara Gallagher
# updated 25 August 2021
# Porpoise Energy Budget outputs and hidden Markov model code
# Figure 4 in Gallagher et al. (2021)
# See main text and TRACE section 7 for details

library(tidyverse)
library(moveHMM)
library(momentuHMM)

### read in movement outputs

moveOutSelLM <- read_csv("data/ModelOutputs/MoveDataHMM.csv")

### setup covs as factors
moveOutSelLM<-moveOutSelLM[,c("ID","xcor","ycor","dateTime","aggLev","lgthFish","dailyFish","nPorpsHere","doa")]
moveOutSelLM$ID<-as.factor(moveOutSelLM$ID)
moveOutSelLM$aggLev<-as.factor(moveOutSelLM$aggLev)
moveOutSelLM$lgthFish<-as.factor(moveOutSelLM$lgthFish)
moveOutSelLM$doa<-as.factor(moveOutSelLM$doa)
moveOutSelLM <- as.data.frame(moveOutSelLM)

### prep data for HMM 
moveOutSelLM <- prepData(moveOutSelLM,type="UTM",coordNames=c("xcor","ycor"))

### filter out occurances where porpoises moved from one side of the map to the other
step1<-ifelse(moveOutSelLM$step>=100,NA,moveOutSelLM$step)
moveOutSelLM$step<-step1

xcor1<-ifelse(is.na(moveOutSelLM$step),NA,moveOutSelLM$x)
ycor1<-ifelse(is.na(moveOutSelLM$step),NA,moveOutSelLM$y)

moveOutSelLM$x<-xcor1
moveOutSelLM$y<-ycor1

#summary(moveOutSelLM)

### initial parameters for gamma and von Mises distributions
mu0 <- c(0.1,1) # step mean (two parameters: one for each state)
sigma0 <- c(0.1,1) # step SD
zeromass0 <- c(0.1,0.05) # step zero-mass
stepPar0 <- c(mu0,sigma0,zeromass0)
angleMean0 <- c(pi,0) # angle mean
kappa0 <- c(1,1) # angle concentration
anglePar0 <- c(angleMean0,kappa0)
Par0 <-list(step=stepPar0,angle=anglePar0)
dist<-list(step = "gamma", angle = "vm")


### fit a model to each combination of covariates
m <- fitHMM(data=moveOutSelLM,nbStates=2,Par0=Par0,dist=dist,
            estAngleMean = list(angle=TRUE),formula=~1)
m
plot(m)


m1 <- fitHMM(data=moveOutSelLM,nbStates=2,Par0=Par0,dist=dist,
             estAngleMean = list(angle=TRUE),formula=~doa)
m1
plot(m1, plotCI = TRUE)


m2 <- fitHMM(data=moveOutSelLM,nbStates=2,Par0=Par0,dist=dist,
             estAngleMean = list(angle=TRUE),formula=~lgthFish)
m2
plot(m2, plotCI = TRUE)


m3 <- fitHMM(data=moveOutSelLM,nbStates=2,Par0=Par0,dist=dist,
             estAngleMean = list(angle=TRUE),formula=~aggLev)
m3
plot(m3, plotCI = TRUE)

m4 <- fitHMM(data=moveOutSelLM,nbStates=2,Par0=Par0,dist=dist,
             estAngleMean = list(angle=TRUE),formula=~aggLev + lgthFish)
m4
plot(m4, plotCI = TRUE)

m5 <- fitHMM(data=moveOutSelLM,nbStates=2,Par0=Par0,dist=dist,
             estAngleMean = list(angle=TRUE),formula=~doa + aggLev + lgthFish)
m5
plot(m5, plotCI = TRUE)


### AIC values
AIC(m)
AIC(m1)
AIC(m2)
AIC(m3)
AIC(m4)
AIC(m5)

moveOutDataDoALA <- moveOutSelLM

### decode most likely state sequence for best fitting model (m5)
moveOutDataDoALA$states <- viterbi(m5)

### derive percentage of time spent in each state for each covariate value - shown for best fitting model (m5)
table(moveOutDataDoALA$states[moveOutDataDoALA$doa=="dead"])/nrow(moveOutDataDoALA[moveOutDataDoALA$doa=="dead",])
table(moveOutDataDoALA$states[moveOutDataDoALA$doa=="alive"])/nrow(moveOutDataDoALA[moveOutDataDoALA$doa=="alive",])
table(moveOutDataDoALA$states[moveOutDataDoALA$aggLev==2])/nrow(moveOutDataDoALA[moveOutDataDoALA$aggLev==2,])
table(moveOutDataDoALA$states[moveOutDataDoALA$aggLev==12])/nrow(moveOutDataDoALA[moveOutDataDoALA$aggLev==12,])
table(moveOutDataDoALA$states[moveOutDataDoALA$aggLev==22])/nrow(moveOutDataDoALA[moveOutDataDoALA$aggLev==22,])
table(moveOutDataDoALA$states[moveOutDataDoALA$lgthFish==14.1])/nrow(moveOutDataDoALA[moveOutDataDoALA$lgthFish==14.1,])
table(moveOutDataDoALA$states[moveOutDataDoALA$lgthFish==15.35])/nrow(moveOutDataDoALA[moveOutDataDoALA$lgthFish==15.35,])
table(moveOutDataDoALA$states[moveOutDataDoALA$lgthFish==16.6])/nrow(moveOutDataDoALA[moveOutDataDoALA$lgthFish==16.6,])
table(moveOutDataDoALA$states[moveOutDataDoALA$lgthFish==17.85])/nrow(moveOutDataDoALA[moveOutDataDoALA$lgthFish==17.85,])
table(moveOutDataDoALA$states[moveOutDataDoALA$lgthFish==19.1])/nrow(moveOutDataDoALA[moveOutDataDoALA$lgthFish==19.1,])

### gamma for each covariate value in the best fitting model (m5)
DoALAoutD <- CIreal(m5, covs = data.frame(doa = "dead"))
DoALAoutD$gamma
DoALAoutA <- CIreal(m5, covs = data.frame(doa = "alive"))
DoALAoutA$gamma
DoALAout2 <- CIreal(m5, covs = data.frame(aggLev = 2))
DoALAout2$gamma
DoALAout12 <- CIreal(m5, covs = data.frame(aggLev = 12))
DoALAout12$gamma
DoALAout22 <- CIreal(m5, covs = data.frame(aggLev = 22))
DoALAout22$gamma
DoALAout14 <- CIreal(m5, covs = data.frame(lgthFish = 14.1))
DoALAout14$gamma
DoALAout15 <- CIreal(m5, covs = data.frame(lgthFish = 15.35))
DoALAout15$gamma
DoALAout16 <- CIreal(m5, covs = data.frame(lgthFish = 16.6))
DoALAout16$gamma
DoALAout17 <- CIreal(m5, covs = data.frame(lgthFish = 17.85))
DoALAout17$gamma
DoALAout19 <- CIreal(m5, covs = data.frame(lgthFish = 19.1))
DoALAout19$gamma

### gamma for all combinations of covariates in the best fitting model (m5)
DoALAoutD214 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 2, lgthFish = 14.1))
DoALAoutD214$gamma
DoALAoutD215 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 2, lgthFish = 15.35))
DoALAoutD215$gamma
DoALAoutD216 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 2, lgthFish = 16.6))
DoALAoutD216$gamma
DoALAoutD217 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 2, lgthFish = 17.85))
DoALAoutD217$gamma
DoALAoutD219 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 2, lgthFish = 19.1))
DoALAoutD219$gamma

DoALAoutD1214 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 12, lgthFish = 14.1))
DoALAoutD1214$gamma
DoALAoutD1215 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 12, lgthFish = 15.35))
DoALAoutD1215$gamma
DoALAoutD1216 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 12, lgthFish = 16.6))
DoALAoutD1216$gamma
DoALAoutD1217 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 12, lgthFish = 17.85))
DoALAoutD1217$gamma
DoALAoutD1219 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 12, lgthFish = 19.1))
DoALAoutD1219$gamma

DoALAoutD2214 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 22, lgthFish = 14.1))
DoALAoutD2214$gamma
DoALAoutD2215 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 22, lgthFish = 15.35))
DoALAoutD2215$gamma
DoALAoutD2216 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 22, lgthFish = 16.6))
DoALAoutD2216$gamma
DoALAoutD2217 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 22, lgthFish = 17.85))
DoALAoutD2217$gamma
DoALAoutD2219 <- CIreal(m5, covs = data.frame(doa = "dead", aggLev = 22, lgthFish = 19.1))
DoALAoutD2219$gamma

DoALAoutA214 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 2, lgthFish = 14.1))
DoALAoutA214$gamma
DoALAoutA215 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 2, lgthFish = 15.35))
DoALAoutA215$gamma
DoALAoutA216 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 2, lgthFish = 16.6))
DoALAoutA216$gamma
DoALAoutA217 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 2, lgthFish = 17.85))
DoALAoutA217$gamma
DoALAoutA219 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 2, lgthFish = 19.1))
DoALAoutA219$gamma

DoALAoutA1214 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 12, lgthFish = 14.1))
DoALAoutA1214$gamma
DoALAoutA1215 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 12, lgthFish = 15.35))
DoALAoutA1215$gamma
DoALAoutA1216 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 12, lgthFish = 16.6))
DoALAoutA1216$gamma
DoALAoutA1217 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 12, lgthFish = 17.85))
DoALAoutA1217$gamma
DoALAoutA1219 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 12, lgthFish = 19.1))
DoALAoutA1219$gamma

DoALAoutA2214 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 22, lgthFish = 14.1))
DoALAoutA2214$gamma
DoALAoutA2215 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 22, lgthFish = 15.35))
DoALAoutA2215$gamma
DoALAoutA2216 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 22, lgthFish = 16.6))
DoALAoutA2216$gamma
DoALAoutA2217 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 22, lgthFish = 17.85))
DoALAoutA2217$gamma
DoALAoutA2219 <- CIreal(m5, covs = data.frame(doa = "alive", aggLev = 22, lgthFish = 19.1))
DoALAoutA2219$gamma


############ Plotting transition probabilities and percent time in each state ##############################
library(readxl)

# all combinations
outs <- read_excel("data/ModelOutputs/MoveModsTransProbsAllCombos.xlsx")

outs <- rename(outs, 
               OneToOne = '1to1', 
               OneToOnese = '1to1se',
               OneToTwo = '1to2', 
               OneToTwose = '1to2se',
               TwoToOne = '2to1', 
               TwoToOnese = '2to1se',
               TwoToTwo = '2to2', 
               TwoToTwose = '2to2se')

outs$DoA <- factor(outs$DoA, levels=unique(outs$DoA))
outs$AL <- factor(outs$AL, levels=unique(outs$AL))
outs$FL <- factor(outs$FL, levels=unique(outs$FL))


outs <- outs %>% 
  mutate(DoA = ifelse(DoA == "dead", "Died", "Survived"))

aggLev.labs <- c("Low", "Moderate", "High")
names(aggLev.labs) <- c(2,12,22)

TPplot <- ggplot(outs, aes(x = FL, y = OneToTwo, shape = DoA)) +
  geom_point() + 
  geom_linerange(aes(ymin = OneToTwo - OneToTwose, ymax =  OneToTwo + OneToTwose)) +
  facet_wrap(~AL, labeller = labeller(aggLev = aggLev.labs)) +
  ggtitle("1 > 2") +
  labs(y = "Probability", x = "Final fish length [cm]", col = NULL, title = NULL) +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.grid.major = element_line(colour = "gray95", size=0.5),
    panel.grid.minor.y = element_line(colour = "gray95", size=0.5),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank())
TPplot

################ activity budgets per day ########################
# dead example
ABoutD <- moveOutDataDoALA %>% 
  filter(ID == 72390) 
ABoutD <- ABoutD %>% mutate(day=c(rep(1:(nrow(ABoutD)/24), each = 24)))
ABoutD <- table(ABoutD$states,ABoutD$day)
ABoutD <- as.data.frame(ABoutD)
ABoutD$Freq <- ABoutD$Freq / 24
ABoutD$DoA <- "Died"

# survived example
ABoutA <- moveOutDataDoALA %>% 
  filter(ID == 78463) 
ABoutA <- ABoutA %>% mutate(day=c(rep(1:(nrow(ABoutA)/24), each = 24)))
ABoutA <- table(ABoutA$states,ABoutA$day)
ABoutA <- as.data.frame(ABoutA)
ABoutA$Freq <- ABoutA$Freq / 24
ABoutA$DoA <- "Survived"

ABAll <- rbind(ABoutD, ABoutA)

ABplot <- ggplot(ABAll, aes(x = Var2, y = Freq, fill = Var1)) +
  geom_col() +
  facet_grid(rows = vars(DoA))+
  labs(x = "Days", y = "Activity budget", fill = "State") +
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    legend.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    legend.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank())

# FIGURE 4 #
TPplot / ABplot + plot_layout(ncol=1,heights=c(2,1))

