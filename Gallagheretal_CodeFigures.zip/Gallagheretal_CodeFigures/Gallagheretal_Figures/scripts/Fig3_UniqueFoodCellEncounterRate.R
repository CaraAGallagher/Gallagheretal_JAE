# Cara Gallagher
# updated 25 August 2021
# Porpoise Energy Budget outputs
# Figure 3 in Gallagher et al. (2021)
# See main text and TRACE section 7 for details

library(wesanderson)
library(tidyverse)
library(see)
library(patchwork)

################ colors #######################

pal <- wes_palette("Darjeeling1", 5, type = "continuous")

############### Space use outputs #####################

PatchOut <- read_csv("data/ModelOutputs/SpaceUseOut.csv")

# unique food cell encounters by seascape aggregation level

ufceAL <- PatchOut %>% 
  filter(lgthFish == 16.6) %>% 
  mutate(xcor = ifelse(aggLev == 2, 0.5, ifelse(aggLev == 12, 1, 1.5)))

ufceALPlot <- ggplot(ufceAL,aes(x=xcor,y=Patch,fill=as.factor(aggLev)))+
  geom_violinhalf(aes(fill=as.factor(aggLev)), scale = "width", col = "grey30", trim=FALSE,alpha=.5, position = position_nudge(x = 0.025), size = 1)+
  geom_boxplot(aes(x=xcor,y=Patch,fill=as.factor(aggLev)),outlier.shape=NA,width=.045,colour="grey30", position = position_nudge(x = -0.025),lwd = 1.25, fatten = 1.25)+
  scale_colour_brewer(palette="Dark2")+
  scale_fill_brewer(palette="Dark2")+
  scale_x_continuous(breaks = c(0.5,1,1.5), labels = c("Low", "Moderate", "High")) +
  labs(x = "Aggregation level", y = "Unique food cell encounters [N]") +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank())

# unique patch visits by month of year

ufceMonth <- PatchOut %>% 
  filter(aggLev == 12, lgthFish == 16.6) %>% 
  mutate(floorYear = floor(year)) %>%
  mutate(pInYear = year - floorYear) %>% 
  group_by(runNum, floorYear) %>% 
  mutate( group = cur_group_id() )

ufceMonthPlot <- ggplot(ufceMonth)+
  geom_line(aes(x = pInYear,y = Patch, group = group), col = "grey40", size = 1.25, alpha = 0.1) +
  geom_smooth(aes(x = pInYear,y = Patch), se = FALSE, size = 1.5, col = "slateblue4") +
  scale_x_continuous(breaks = seq(0.08173077/2, 0.9807692, 0.08173077), labels = c(1:12)) +
  labs(x = "Month", y = "Unique food cell encounters [N]") +
  theme(
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank())

# unique patch visits by fish length

ufceFL <- PatchOut %>% 
  filter(aggLev == 22) %>% 
  filter(year >= 15 & year < 15 + 0.08333333 )

ufceFLPlot <- ggplot(ufceFL, aes(x = as.factor(lgthFish), y = Patch, fill = as.factor(lgthFish)))+
  geom_boxplot(lwd = 1.25, fatten = 1.25, col = "grey30")+
  labs(x = "Final fish length [cm]", y = "Unique food cell encounters [N]") +
  scale_fill_manual(values = pal) +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 9, color = "gray40", face = "bold"),
    axis.text = element_text(size = 8, color = "gray40", face = "bold"),
    axis.line = element_line(colour = "gray40", size=0.9),
    axis.ticks= element_line(colour = "gray40", size=0.9),
    panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
    panel.background = element_blank())


## all together

Figure3 <- ufceALPlot + ufceMonthPlot + ufceFLPlot + 
  plot_layout(widths = c(0.75,1.0,1.0))
Figure3

